package br.edu.ifpr.atvvv1;

import java.io.*;

import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;

@WebServlet(name = "cabecalho", value = "/cabecalho")
public class Cabecalho extends HttpServlet {
    private String string;

    public void init() {
        string = "Cabeçalho - <a href='/testeApp'> Voltar </a>";
    }

    public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {

        response.setContentType("text/html");

        PrintWriter out = response.getWriter();
        out.println("<html><body>");
        out.println("<h1>" + string + "</h1>");

        String host = request.getHeader("host");
        String useragent = request.getHeader("user-agent");
        String acceptencoding = request.getHeader("accept-encoding");
        String acceptlanguage = request.getHeader("accept-language");

        out.println("host: " + host);
        out.println("<br>");
        out.println("accept-language: " + acceptlanguage);
        out.println("<br>");
        out.println("user Agent: " + useragent);
        out.println("<br>");
        out.println("accept-encoding: " + acceptencoding);

        out.println("</body></html>");
    }

    public void destroy() {
    }
}