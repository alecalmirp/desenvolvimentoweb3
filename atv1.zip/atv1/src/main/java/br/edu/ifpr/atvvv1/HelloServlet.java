package br.edu.ifpr.atvvv1;

import java.io.*;

import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;

@WebServlet(name = "helloServlet", value = "/hello-servlet")
public class HelloServlet extends HttpServlet {
    private String string;

    public void init() {
        string = "hello world - <a href='/testeApp'> Voltar </a>";
    }

    public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setContentType("text/html");

        PrintWriter out = response.getWriter();
        out.println("<html><body>");
        out.println(string);
        out.println("</body></html>");
    }

    public void destroy() {
    }
}