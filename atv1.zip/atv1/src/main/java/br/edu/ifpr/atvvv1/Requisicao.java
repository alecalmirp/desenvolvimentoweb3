package br.edu.ifpr.atvvv1;

import java.io.*;

import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;

@WebServlet(name = "requisicao", value = "/requisicao")
public class Requisicao extends HttpServlet {
    private String string;

    public void init() {
        string = "Requisicao - <a href='/testeApp'> Voltar </a>";
    }

    public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setContentType("text/html");

        PrintWriter out = response.getWriter();
        out.println("<html><body>");

        out.println(string);

        String method = request.getMethod();
        out.println("Method: " + method);
        out.println("<br>");

        String requestURI = request.getRequestURI();
        out.println("URI: " + requestURI);
        out.println("<br>");

        String protocol = request.getProtocol();
        out.println("Protocol: " + protocol);
        out.println("<br>");

        String remoteAddr = request.getRemoteAddr();
        out.println("Remote Address: " + remoteAddr);
        out.println("<br>");

        out.println("</body></html>");
    }

    public void destroy() {
    }
}